// ==UserScript==
// @name         GitHub.com国内加速访问
// @version      1.0
// @description  使用国外加速网站，加速解决GitHub国内访问一切幺蛾子
// @match        *://*.github.com/*
// @run-at      document-start
// @grant        none
// @namespace https://greasyfork.org/users/20787
// ==/UserScript==
 
(function() {
    'use strict';
 
    // 获取当前网页链接
    var currentUrl = window.location.href;
 
    // 替换域名为 "githubfast.com"
    var newUrl = currentUrl.replace(window.location.hostname, 'githubfast.com');
 
    // 重新访问新链接
    window.location.href = newUrl;
})();