// ==UserScript==
// @name 抖音网页版优化
// @description 抖音网页版推荐、直播优化，网页全屏，全黑，自动按浏览器窗口调整大小
// @namespace https://space.bilibili.com/482343
// @author 古海沉舟
// @license 古海沉舟
// @version 1.11.4
// @match https://www.douyin.com/*
// @include https://www.douyin.com/recommend
// @include https://www.douyin.com/*
// @include https://www.douyin.com/?*
// @include https://www.douyin.com/follow
// @include https://live.douyin.com/*
// @require https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// @run-at document-end
// @grant GM_setValue
// @grant GM_getValue
// @grant GM_addValueChangeListener
// @noframes
// @downloadURL https://update.greasyfork.org/scripts/434956/%E6%8A%96%E9%9F%B3%E7%BD%91%E9%A1%B5%E7%89%88%E4%BC%98%E5%8C%96.user.js
// @updateURL https://update.greasyfork.org/scripts/434956/%E6%8A%96%E9%9F%B3%E7%BD%91%E9%A1%B5%E7%89%88%E4%BC%98%E5%8C%96.meta.js
// ==/UserScript==
//setTimeout(()=>{
var zz =   new Array("","","","","","","","","","");
var zzb = new Array("","","","","","","","","","");
var lastindex=0,livecount=0,h="",h0="";
var toObj = function( arr ){ var obj = {}; for(var temp in arr){ obj[arr[temp]] = true; } return obj;};
var toArr = function( obj ){ var arr = []; for(var temp in obj){ arr.push(temp); } return arr;};
var together = function( a,b ){ for(var temp=0;temp<b.length;temp++)if(b[temp]!=null && b[temp]!="" && b[temp]!="null" && b[temp].length<40){ a.push(b[temp].toLowerCase()); }};
var getUniq = function(arr){ return toArr( toObj(arr) );};
var zzx = GM_getValue("zz",new Array());
var zzy = GM_getValue("zzb",new Array());
zzx = zzx.filter((itemA) => !zzb.some((itemB) => itemA === itemB));
zzy = zzy.filter((itemA) => !zz.some((itemB) => itemA === itemB));
together(zzx,zz);
zzx =getUniq(zzx);
zz = new Array();
together(zz,zzx);
GM_setValue("zz", zz);
together(zzy,zzb);
zzy =getUniq(zzy);
zzb = new Array();
together(zzb,zzy);
zzb = zzb.filter((itemA) => !zz.some((itemB) => itemA === itemB));
GM_setValue("zzb", zzb);

function keydown(event) {
    //console.log(event.keyCode);
    if(event.keyCode == 109 || event.keyCode == 189){ // 按-或者小键盘-
        pagefullscreen();
    }
}
document.addEventListener('keydown', keydown, false);

var haspagefullscreen=0;
if (location.href.indexOf("douyin.com/follow")>-1){
    haspagefullscreen=1;
    let livestyle = document.createElement('style');
    livestyle.classList.add("live");
    livestyle.innerHTML = `
.QecmPpxX .RUVTDzAp,._dJyrFnU .gsOyYJvT{ border-radius: 0%;  }
.Jt6LO5RK .qOwBZHet .trexWhDY,.yP48EXrf .NvKO9tgN .jnhlhsXZ,.QecmPpxX .RUVTDzAp{ animation: none; }

.Jt6LO5RK .qOwBZHet .y5X4PaKT, .Jt6LO5RK .qOwBZHet .o4w20gFP, div.XcEg0PrM,div.Lo8QPz5R,div.QecmPpxX.TrKWAgc9>svg,div.QecmPpxX.TrKWAgc9 > div.X0v0tibw,div.QecmPpxX.TrKWAgc9 > div.XQ9v_nAP,ul > li > a > div > svg,ul > li > a > div > div.WDUuX4lo,ul > li > a > div > div.SDfWCx4A{ display: none !important }
div[class="iLXEZpcn Wza3QO3S"],div.zhL4qBq2,.yP48EXrf .NvKO9tgN .Pj8z3gc4,div.WQmhtggS,div[data-e2e="recommend-guide-mask"]{display: none!important}

`
    document.body.appendChild(livestyle);
    console.log("直播");
    var liveheight=setInterval(livesort,500);

}
function livesort(){
    $(`#douyin-right-container > div > div > div.II6cheXp >div:eq(1)`).each(function(){
        //console.log($(this)[0]);
        $(this).hide();
    })
    $(`#douyin-right-container > div > div > div.II6cheXp >div:eq(2)`).each(function(){
        //console.log($(this)[0]);
        $(this).hide();
    })
    $(`#douyin-right-container > div > div > div.II6cheXp >div:eq(3)`).each(function(){
        //console.log($(this)[0]);
        $(this).hide();
    })
    $(`#douyin-right-container > div > div > div.II6cheXp >ul:eq(1)`).each(function(){
        console.log($(this)[0]);
        $(this).remove();
    })
    //直播个数
    if ($(`#douyin-right-container > div > div > div.II6cheXp > ul:eq(0)`).html()==h){return;}
    livecount=$(`#douyin-right-container > div > div > div.II6cheXp > ul:eq(0) > li`).length;
    if(livecount>0){
        var h1="";
        var h2="";
        var h3="";
        $(`#douyin-right-container > div > div > div.II6cheXp > ul:eq(0) > li`).each(function(){
            let find=0;
            let fl = $(this).children("a").attr("href");
            if (typeof fl !== "undefined"){
            }else{
                return
            }
            for (let x=0;x<zz.length;x++){
                if(zz[x] != ""){
                    if (fl.indexOf(zz[x])>-1){
                        find=1;
                        break;
                    }
                }
            }
            if (find){
                h1=h1+$(this)[0].outerHTML;
                return
            }

            for (let x=0;x<zzb.length;x++){
                if(zzb[x] != ""){
                    if (fl.indexOf(zzb[x])>-1){
                        find=1;
                        break;
                    }
                }
            }
            if (find){
                h2=h2+$(this)[0].outerHTML;
                return
            }
            h3=h3+$(this)[0].outerHTML;
        })
        h=h1+h2+h3;
        if (h!=""){
            //console.log(h);
            $(`#douyin-right-container > div > div > div.II6cheXp > ul:eq(0)`).html(h);
        }
    }else{
        if (h0!=""){
            $(`#douyin-right-container`).html(h0);
            return
        }
    }
    livecount=$(`#douyin-right-container > div > div > div.II6cheXp > ul:eq(0) > li`).length;
    if (livecount>0 && lastindex==0){
        h0=$(`#douyin-right-container`).html();
        console.log("直播个数",livecount);
        clearInterval(liveheight);
        lastindex=1;
        liveheight=setInterval(livesort,5000);
    }

}
function pagefullscreen(){
    var is=0;
    //$(`#slidelist > div > div.swiper-wrapper > div.swiper-slide-active xg-icon.xgplayer-page-full-screen > div.xgplayer-icon`).click();
    $(`#sliderVideo xg-icon.xgplayer-page-full-screen > div.xgplayer-icon`).each(function(){
        haspagefullscreen=1;
        $(this).click();
        is=1;
        if (is){return}
        console.log("非推荐");
        $(`xg-controls xg-icon>div > div:nth-child(2)`).each(function(){
            if ($(this).parent().text().indexOf("网页全屏")<0)return;
            console.log("判断：",$(this).text(),"  ",$(this)[0]);
            haspagefullscreen=1;
            $(this).click();
        })
    })
    if (is){return}
    $(`div[data-e2e="living-container"] xg-icon>div>div`).each(function(){
        if ($(this).parent().text().indexOf("网页全屏")<0)return;
        console.log("判断：",$(this).text(),"  ",$(this)[0]);
        haspagefullscreen=1;
        $(this).click();
    })

}
var firstfullscreen=setInterval(function(){
    if (haspagefullscreen){
        clearInterval(firstfullscreen);
        return;
    }
    pagefullscreen();
},1000);

setInterval(function(){
    filtergift();
},1000);

function filtergift(){ //过滤直播礼物
    $(`div.webcast-chatroom___item.webcast-chatroom___enter-done`).each(function(){
        if ($(this).text().indexOf("为主播加了")>-1 || $(this).text().indexOf("送出了")>-1 ||$(this).text().indexOf("刚刚升级至")>-1 ||  $(this).text().indexOf("送给")>-1 ||  $(this).text().indexOf("成为在线观众TOP")>-1 || $(this).text().indexOf("推荐直播给")>-1 || $(this).text().indexOf("成功冠名了")>-1 || $(this).text().indexOf("恭喜主播成功点亮了")>-1){
            console.log($(this).text().replace(/\n/g, " ").replace(/\s\s/g, " "));
            $(this).hide();
        }
    })
}

function addCSS(){
    let wdstyle = document.createElement('style');
    wdstyle.classList.add("optimize");
    wdstyle.innerHTML = `
div.gNyVUu_s, .OaNxZqFU img, .iRX47Q8q img,.Ng_nLvWy img,#sliderVideo > div.Mtz1OJlG.v0tRQvoe{ display: none!important }
.yP48EXrf .PzYA0Lei,._fmQtZIm .TWYv_EXn .I7uTRbqE{text-overflow: clip !important;}
.qdcce5kG .VFMR0HAe,:root[update-header="2"] .qlkbkha_{ background: #0000 !important }
.vLt8mbfQ .y8iJbHin .mMOxHVzv, .vLt8mbfQ .y8iJbHin .rrKCA47Q, div.webcast-chatroom, .BasEuG5Q ._QjzkgP3, .OaNxZqFU,.basicPlayer.xgplayer,div.aqK_4_5U,.iSgCRqVf,.aEzDlumt .KhphjUgd.lG3F75Kf.anFLc8TW{ background: #000 !important }
body,.Npz7CPXj, div.webcast-chatroom .webcast-chatroom___input-container .webcast-chatroom___textarea, .CgAB9miy, .JTIGfG2P, .NQ38Bc0h .XcEg0PrM, .N_HNXA04:not(.dUiu6B8O) .iViO9oMI, .UKFpY5tW, .SxCiQ8ip .EDvjMGPs,.SxCiQ8ip .A0ewbQCI,.fpRIB_wC,div.tgMCqIjJ, div.tgMCqIjJ.isDark,.sELpHy0M.metro .lgs6xhy7 .slot-item:hover,.sELpHy0M.metro .B9p3ney8:hover,.sELpHy0M.metro .UjStUCgW ._BSUxMOF:hover,.SxCiQ8ip.V6Va18Np,#slidelist,.qlkbkha_,.SxMeCeGo.UdVKTDud .gjQTl671,.h9wtZ0fY.metro .wtNw_CDe:hover,.h9wtZ0fY.metro .Pg8ernIx .slot-item:hover,.h9wtZ0fY.metro .fIHFYwJt .Y4MTL_BH:hover,.SxMeCeGo .DFH1PTN6,.gjQTl671,.EexPxRCK.cc1_mSqr.Bhtzbjo2,.aEzDlumt .jscIDlNp,.aEzDlumt .jscIDlNp.anFLc8TW{ background: #111 !important }
.N_HNXA04:not(.dUiu6B8O) .kQ2JnIMK .n9PPTk22, .N_HNXA04 .kQ2JnIMK, .iwzpXgQ3 .oJArD0aS, .xWPMYXKp .gOSlkVoB, .Exz5X5r1,.R5ITbXfy .k5cuEeRD,.sELpHy0M.metro .lgs6xhy7 .slot-item,.sELpHy0M.metro .B9p3ney8,.sELpHy0M.metro .UjStUCgW ._BSUxMOF,.N_HNXA04 .kQ2JnIMK .YrFhKzRI,.kuew7rkS .HaiBJL6n,.h9wtZ0fY.metro .wtNw_CDe,.h9wtZ0fY.metro .Pg8ernIx .slot-item,.h9wtZ0fY.metro .fIHFYwJt .Y4MTL_BH,._0QL2JpzH{ background: #222 !important }
div.JwGiJkkI, div.xgplayer-dynamic-bg, div.umOY7cDY, div.ruqvqPsH,footer{ display: none !important }
.L8o4Hyg1,.L8o4Hyg1 .LFbb1oon,.L8o4Hyg1 .R6NHkCAw .i4vdvOF5{ box-shadow: none !important; border-bottom: none !important; border-right: none !important; }
.N_HNXA04:not(.JVPLvXh3) .iViO9oMI,.N_HNXA04 .HQwsRJFy,.lXuWkeYW, .lXuWkeYW .oJArD0aS{height:60px !important}
.pgQgzInF.hqONwptG .Jf1GlewW.Ox89VrU5, .ckEyweZa.AmXnh1GR .QICHGW7r.RosH2lNv, .SxCiQ8ip.V6Va18Np .EDvjMGPs.FKQqfehj { height: 100% !important; }
:root[update-header="1"] .JTIGfG2P, :root[update-header="2"] .JTIGfG2P, :root[update-header="3"] .JTIGfG2P{padding: 0 0 0 0;}
.SxCiQ8ip .EDvjMGPs .nUwhpww3.E2QLXZIv{padding-top: 0px;}
div.immersive-player-switch-on-hide-interaction-area, #video-info-wrap, xg-inner-controls.xg-inner-controls { opacity: 0.6 !important }
.xgplayer-playswitch .xgplayer-playswitch-tab { opacity: 0 !important }
div.xgplayer-playswitch-tab:hover, div.immersive-player-switch-on-hide-interaction-area:hover, #video-info-wrap:hover, xg-inner-controls.xg-inner-controls:hover { opacity: 1 !important }
.mUQC4JAd .LU6dHmmD{color:#bbb}
`
    document.body.appendChild(wdstyle);
}
addCSS();

//},1500)